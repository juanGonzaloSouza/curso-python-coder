from setuptools import setup

setup (
    name="Segunda_pre_entrega",
    packages=["paquete", "paquete/compra"]
)